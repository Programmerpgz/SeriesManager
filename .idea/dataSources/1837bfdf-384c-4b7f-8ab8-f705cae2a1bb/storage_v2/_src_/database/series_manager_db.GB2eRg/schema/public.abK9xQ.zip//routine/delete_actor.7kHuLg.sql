create procedure delete_actor(IN p_id integer)
    language plpgsql
as
$$
BEGIN
    DELETE FROM actor WHERE id = p_id;
END;
$$;

alter procedure delete_actor(integer) owner to postgres;

