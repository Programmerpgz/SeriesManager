create function create_series(p_name character varying, p_desc text, p_seasons integer, p_episodes integer, p_path character varying, p_year integer, p_end_year integer, p_genre character varying, p_platform character varying, p_dir_name character varying, p_dir_surname character varying) returns integer
    language plpgsql
as
$$
DECLARE
    new_id integer;
    d_id integer;
BEGIN
    -- 1. Pronađi ili umetni direktora
    SELECT id INTO d_id FROM director 
    WHERE name = p_dir_name AND surname = p_dir_surname;
    
    IF d_id IS NULL THEN
        INSERT INTO director (name, surname) VALUES (p_dir_name, p_dir_surname) 
        RETURNING id INTO d_id;
    END IF;

    -- 2. Umetni seriju
    INSERT INTO series (
        name, description, number_of_seasons, number_of_episodes, 
        poster_path, year_of_release, end_year, genre, platform, director_id
    )
    VALUES (
        p_name, p_desc, p_seasons, p_episodes, 
        p_path, p_year, p_end_year, p_genre, p_platform, d_id
    )
    RETURNING id INTO new_id;

    RETURN new_id;
END;
$$;

alter function create_series(varchar, text, integer, integer, varchar, integer, integer, varchar, varchar, varchar, varchar) owner to postgres;

