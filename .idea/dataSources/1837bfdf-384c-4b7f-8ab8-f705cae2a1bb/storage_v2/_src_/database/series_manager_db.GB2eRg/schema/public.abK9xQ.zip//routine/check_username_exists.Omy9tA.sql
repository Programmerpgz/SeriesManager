create function check_username_exists(p_username character varying) returns integer
    language plpgsql
as
$$
BEGIN
    RETURN (SELECT COUNT(*)::INT FROM users WHERE username = p_username);
END; $$;

alter function check_username_exists(varchar) owner to postgres;

