create function get_all_users()
    returns TABLE(id integer, username character varying, password character varying, surname character varying, name character varying, email character varying, role character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM users;
END; $$;

alter function get_all_users() owner to postgres;

