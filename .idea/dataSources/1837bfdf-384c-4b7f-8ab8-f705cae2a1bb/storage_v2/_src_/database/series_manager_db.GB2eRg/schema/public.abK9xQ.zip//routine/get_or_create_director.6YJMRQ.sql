create function get_or_create_director(p_name text, p_surname text, p_year_of_birth integer, p_nationality text, p_biography text)
    returns TABLE(id integer, name text, surname text, year_of_birth integer, nationality text, biography text)
    language plpgsql
as
$$
BEGIN

    BEGIN
        INSERT INTO director(
            name,
            surname,
            year_of_birth,
            nationality,
            biography
        )
        VALUES (
            p_name,
            p_surname,
            p_year_of_birth,
            p_nationality,
            p_biography
        );

    EXCEPTION
        WHEN unique_violation THEN
            NULL;
    END;

    RETURN QUERY
SELECT
    d.id,
    d.name::text,
    d.surname::text,
    d.year_of_birth,
    d.nationality::text,
    d.biography::text
FROM director d
WHERE lower(d.name) = lower(p_name)
  AND lower(d.surname) = lower(p_surname)
LIMIT 1;

END;
$$;

alter function get_or_create_director(text, text, integer, text, text) owner to postgres;

