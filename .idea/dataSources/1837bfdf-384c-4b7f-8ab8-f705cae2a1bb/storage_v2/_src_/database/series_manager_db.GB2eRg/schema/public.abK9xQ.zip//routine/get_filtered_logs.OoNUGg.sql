create function get_filtered_logs(p_level_filter character varying)
    returns TABLE(id integer, ts timestamp without time zone, uname character varying, act text, lvl character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT user_logs.id, user_logs.timestamp, user_logs.username, user_logs.action, user_logs.level
    FROM user_logs
    WHERE (p_level_filter = 'ALL' OR user_logs.level = p_level_filter)
    ORDER BY user_logs.timestamp DESC;
END;
$$;

alter function get_filtered_logs(varchar) owner to postgres;

