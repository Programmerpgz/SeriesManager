create function get_all_actors()
    returns TABLE(id integer, name character varying, surname character varying, year_of_birth integer, nationality character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT a.id, a.name, a.surname, a.year_of_birth, a.nationality 
    FROM actor a ORDER BY a.name;
END; 
$$;

alter function get_all_actors() owner to postgres;

