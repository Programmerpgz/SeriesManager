create procedure delete_all_series()
    language plpgsql
as
$$
BEGIN
    DELETE FROM series;
END;
$$;

alter procedure delete_all_series() owner to postgres;

