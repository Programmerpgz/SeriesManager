create function get_user_watchlist(p_user_id integer)
    returns TABLE(idseries integer, seriesname character varying, seriesdescription text, numberofepisodes integer, numberofseasons integer, yearofrelease integer, endyear integer, picturepath character varying, genres text, platforms text, directorname character varying, actors text)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT 
        s.id AS idSeries, 
        s.name AS seriesName, 
        s.description AS seriesDescription, 
        s.number_of_episodes AS numberOfEpisodes, 
        s.number_of_seasons AS numberOfSeasons, 
        s.year_of_release AS yearOfRelease, 
        s.end_year AS endYear, 
        s.poster_path AS picturePath,
        -- Dohvaćamo žanrove iz series_genre tablice
		COALESCE((SELECT STRING_AGG(sg.genre, ', ') FROM series_genre sg WHERE sg.series_id = s.id), 'N/A'),
        -- Dohvaćamo platforme iz series_platform tablice
        COALESCE((SELECT STRING_AGG(sp.platform, ', ') FROM series_platform sp WHERE sp.series_id = s.id), 'N/A'),
        -- Direktor
		COALESCE((
            SELECT (d.name || ' ' || d.surname)::VARCHAR 
            FROM director d 
            WHERE d.id = s.director_id
        ), 'N/A')::VARCHAR,
		COALESCE((
            SELECT STRING_AGG(act.name || ' ' || act.surname, ', ') 
            FROM series_actor sa 
            JOIN actor act ON sa.actor_id = act.id 
            WHERE sa.series_id = s.id
        ), 'N/A')
    FROM series s
    JOIN watchlist w ON s.id = w.series_id
    WHERE w.user_id = p_user_id;
END; $$;

alter function get_user_watchlist(integer) owner to postgres;

