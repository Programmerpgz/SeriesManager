create procedure insert_user(IN p_username character varying, IN p_password character varying, IN p_name character varying, IN p_surname character varying, IN p_email character varying, IN p_role character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO users (username, password, name, surname, email, role)
    VALUES (p_username, p_password, p_name, p_surname, p_email, p_role);
END;
$$;

alter procedure insert_user(varchar, varchar, varchar, varchar, varchar, varchar) owner to postgres;

