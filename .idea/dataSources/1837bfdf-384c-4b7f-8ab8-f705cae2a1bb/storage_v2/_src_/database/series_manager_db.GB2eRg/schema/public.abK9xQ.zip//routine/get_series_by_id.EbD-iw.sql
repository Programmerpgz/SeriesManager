create function get_series_by_id(p_id integer) returns SETOF series
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM public.series WHERE id = p_id;
END;
$$;

alter function get_series_by_id(integer) owner to postgres;

