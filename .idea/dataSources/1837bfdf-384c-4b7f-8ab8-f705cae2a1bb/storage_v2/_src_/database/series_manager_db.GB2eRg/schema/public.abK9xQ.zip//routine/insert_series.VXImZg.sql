create procedure insert_series(IN p_name character varying, IN p_seasons integer, IN p_episodes integer, IN p_year integer, IN p_end_year integer, IN p_desc text, IN p_poster character varying, IN p_genre character varying, IN p_platform character varying, IN p_director_id integer)
    language plpgsql
as
$$
BEGIN
    INSERT INTO series (
        name, number_of_seasons, number_of_episodes, 
        year_of_release, end_year, description, 
        poster_path, genre, platform, director_id
    )
    VALUES (
        p_name, p_seasons, p_episodes, 
        p_year, p_end_year, p_desc, 
        p_poster, p_genre, p_platform, p_director_id
    );
END;
$$;

alter procedure insert_series(varchar, integer, integer, integer, integer, text, varchar, varchar, varchar, integer) owner to postgres;

