create procedure insert_series_actor(IN p_sid integer, IN p_aid integer)
    language plpgsql
as
$$ BEGIN INSERT INTO series_actor VALUES (p_sid, p_aid); END; $$;

alter procedure insert_series_actor(integer, integer) owner to postgres;

