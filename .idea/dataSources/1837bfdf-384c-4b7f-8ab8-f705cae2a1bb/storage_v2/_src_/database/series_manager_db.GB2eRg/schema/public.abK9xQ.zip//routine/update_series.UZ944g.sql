create procedure update_series(IN p_id integer, IN p_name character varying, IN p_seasons integer, IN p_episodes integer, IN p_year integer, IN p_end_year integer, IN p_desc text, IN p_poster character varying, IN p_director_id integer)
    language plpgsql
as
$$
BEGIN
    UPDATE series 
    SET name = p_name, number_of_seasons = p_seasons, number_of_episodes = p_episodes, 
        year_of_release = p_year, end_year = p_end_year, description = p_desc, 
        poster_path = p_poster, director_id = p_director_id
    WHERE id = p_id;
END;
$$;

alter procedure update_series(integer, varchar, integer, integer, integer, integer, text, varchar, integer) owner to postgres;

