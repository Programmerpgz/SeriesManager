create function search_series(p_keyword text) returns SETOF series
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT * FROM series s 
    WHERE LOWER(s.name) LIKE LOWER('%' || p_keyword || '%');
END;
$$;

alter function search_series(text) owner to postgres;

