create function get_emitting_series() returns SETOF series
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT * FROM public.series s 
    WHERE s.end_year IS NULL; -- Pretpostavljam da ti je ovo logika za "still emitting"
END;
$$;

alter function get_emitting_series() owner to postgres;

