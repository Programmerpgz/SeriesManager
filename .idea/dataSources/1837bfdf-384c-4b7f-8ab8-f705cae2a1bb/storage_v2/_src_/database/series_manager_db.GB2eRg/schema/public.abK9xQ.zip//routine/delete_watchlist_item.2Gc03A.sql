create procedure delete_watchlist_item(IN p_user_id integer, IN p_series_id integer)
    language plpgsql
as
$$
BEGIN
    DELETE FROM watchlist 
    WHERE user_id = p_user_id AND series_id = p_series_id;
END; $$;

alter procedure delete_watchlist_item(integer, integer) owner to postgres;

