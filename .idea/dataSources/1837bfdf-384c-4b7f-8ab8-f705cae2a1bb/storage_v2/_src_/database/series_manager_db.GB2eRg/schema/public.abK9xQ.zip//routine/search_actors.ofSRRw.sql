create function search_actors(p_keyword text) returns SETOF actor
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT * FROM actor a 
    WHERE LOWER(a.name) LIKE LOWER('%' || p_keyword || '%')
       OR LOWER(a.surname) LIKE LOWER('%' || p_keyword || '%');
END;
$$;

alter function search_actors(text) owner to postgres;

