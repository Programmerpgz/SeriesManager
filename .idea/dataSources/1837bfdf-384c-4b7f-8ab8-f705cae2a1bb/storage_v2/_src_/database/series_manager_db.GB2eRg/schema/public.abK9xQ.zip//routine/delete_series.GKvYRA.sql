create procedure delete_series(IN p_id integer)
    language plpgsql
as
$$
BEGIN
    DELETE FROM series WHERE id = p_id;
END;
$$;

alter procedure delete_series(integer) owner to postgres;

