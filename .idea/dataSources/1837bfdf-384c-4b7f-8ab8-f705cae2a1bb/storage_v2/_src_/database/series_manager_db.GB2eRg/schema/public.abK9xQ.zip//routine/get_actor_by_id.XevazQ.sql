create function get_actor_by_id(p_id integer)
    returns TABLE(id integer, name character varying, surname character varying, year_of_birth integer, nationality character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT a.id, a.name, a.surname, a.year_of_birth, a.nationality
    FROM actor a 
    WHERE a.id = p_id;
END; 
$$;

alter function get_actor_by_id(integer) owner to postgres;

