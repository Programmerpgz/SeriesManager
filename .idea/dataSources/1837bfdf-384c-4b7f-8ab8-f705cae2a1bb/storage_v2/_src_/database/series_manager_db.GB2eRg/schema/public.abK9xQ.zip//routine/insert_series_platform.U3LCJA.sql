create procedure insert_series_platform(IN p_sid integer, IN p_platform character varying)
    language plpgsql
as
$$ BEGIN INSERT INTO series_platform VALUES (p_sid, p_platform); END; $$;

alter procedure insert_series_platform(integer, varchar) owner to postgres;

