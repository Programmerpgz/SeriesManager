create function count_user_occurrences(p_username character varying) returns integer
    language plpgsql
as
$$
BEGIN
    RETURN (SELECT COUNT(*)::INT FROM users WHERE username = p_username);
END; $$;

alter function count_user_occurrences(varchar) owner to postgres;

