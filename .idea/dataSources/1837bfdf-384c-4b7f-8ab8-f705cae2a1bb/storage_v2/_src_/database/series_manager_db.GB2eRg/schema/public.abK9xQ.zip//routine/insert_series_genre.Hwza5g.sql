create procedure insert_series_genre(IN p_sid integer, IN p_genre character varying)
    language plpgsql
as
$$ BEGIN INSERT INTO series_genre VALUES (p_sid, p_genre); END; $$;

alter procedure insert_series_genre(integer, varchar) owner to postgres;

