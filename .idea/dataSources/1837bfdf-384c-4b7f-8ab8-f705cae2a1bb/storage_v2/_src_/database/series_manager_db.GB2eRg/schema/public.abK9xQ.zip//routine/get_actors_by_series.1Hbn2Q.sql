create function get_actors_by_series(p_sid integer)
    returns TABLE(id integer, name character varying, nationality character varying, year_of_birth integer, surname character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT a.id, a.name, a.nationality, a.year_of_birth, a.surname 
    FROM actor a JOIN series_actor sa ON a.id = sa.actor_id WHERE sa.series_id = p_sid;
END; $$;

alter function get_actors_by_series(integer) owner to postgres;

