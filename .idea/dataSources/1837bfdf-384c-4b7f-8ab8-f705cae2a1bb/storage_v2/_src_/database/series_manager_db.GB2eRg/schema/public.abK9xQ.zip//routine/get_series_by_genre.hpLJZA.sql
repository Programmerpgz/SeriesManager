create function get_series_by_genre(p_genre text) returns SETOF series
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT * FROM public.series 
    WHERE genre ILIKE ('%' || p_genre || '%');
END;
$$;

alter function get_series_by_genre(text) owner to postgres;

