create procedure create_series_actor(IN p_series_id integer, IN p_actor_name character varying, IN p_actor_surname character varying)
    language plpgsql
as
$$
DECLARE
    v_actor_id INTEGER;
BEGIN
    -- 1. Nađi ili kreiraj glumca
    SELECT id INTO v_actor_id FROM public.actor 
    WHERE name = p_actor_name AND surname = p_actor_surname LIMIT 1;

    IF v_actor_id IS NULL THEN
        INSERT INTO public.actor (name, surname) 
        VALUES (p_actor_name, p_actor_surname) 
        RETURNING id INTO v_actor_id;
    END IF;

    -- 2. Poveži sa serijom (ignore ako već postoji)
    INSERT INTO public.series_actor (series_id, actor_id)
    VALUES (p_series_id, v_actor_id)
    ON CONFLICT DO NOTHING; 
END;
$$;

alter procedure create_series_actor(integer, varchar, varchar) owner to postgres;

