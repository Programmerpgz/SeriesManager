create procedure delete_director(IN p_id integer)
    language plpgsql
as
$$
BEGIN
    UPDATE series SET director_id = NULL WHERE director_id = p_id;
    DELETE FROM director WHERE id = p_id;
END; $$;

alter procedure delete_director(integer) owner to postgres;

