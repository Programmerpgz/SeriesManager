create procedure update_director(IN p_id integer, IN p_name character varying, IN p_surname character varying, IN p_year_of_birth integer, IN p_nationality character varying, IN p_biography character varying)
    language plpgsql
as
$$
BEGIN
    UPDATE director
    SET name          = p_name,
        surname       = p_surname,
        year_of_birth = p_year_of_birth,
        nationality   = p_nationality,
        biography     = p_biography
    WHERE id = p_id;
END;
$$;

alter procedure update_director(integer, varchar, varchar, integer, varchar, varchar) owner to postgres;

