create function get_user_by_id(p_id integer)
    returns TABLE(id integer, username character varying, password character varying, surname character varying, name character varying, email character varying, role character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM users u WHERE u.id = p_id;
END; $$;

alter function get_user_by_id(integer) owner to postgres;

