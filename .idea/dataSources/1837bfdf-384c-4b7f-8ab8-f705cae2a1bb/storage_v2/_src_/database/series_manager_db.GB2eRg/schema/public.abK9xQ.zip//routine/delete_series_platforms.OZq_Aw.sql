create procedure delete_series_platforms(IN p_sid integer)
    language plpgsql
as
$$ BEGIN DELETE FROM series_platform WHERE series_id = p_sid; END; $$;

alter procedure delete_series_platforms(integer) owner to postgres;

