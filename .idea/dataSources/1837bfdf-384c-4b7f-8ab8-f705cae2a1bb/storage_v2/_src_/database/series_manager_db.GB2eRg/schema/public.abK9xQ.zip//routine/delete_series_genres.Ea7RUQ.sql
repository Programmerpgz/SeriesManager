create procedure delete_series_genres(IN p_sid integer)
    language plpgsql
as
$$ BEGIN DELETE FROM series_genre WHERE series_id = p_sid; END; $$;

alter procedure delete_series_genres(integer) owner to postgres;

