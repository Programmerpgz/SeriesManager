create function get_users_by_role(p_role character varying)
    returns TABLE(id integer, username character varying, password character varying, surname character varying, name character varying, email character varying, role character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM users u WHERE u.role = p_role;
END; $$;

alter function get_users_by_role(varchar) owner to postgres;

