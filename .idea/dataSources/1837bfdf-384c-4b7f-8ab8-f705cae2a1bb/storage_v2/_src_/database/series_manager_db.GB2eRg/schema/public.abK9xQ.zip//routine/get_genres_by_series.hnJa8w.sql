create function get_genres_by_series(p_sid integer)
    returns TABLE(genre character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT sg.genre FROM series_genre sg WHERE sg.series_id = p_sid;
END; $$;

alter function get_genres_by_series(integer) owner to postgres;

