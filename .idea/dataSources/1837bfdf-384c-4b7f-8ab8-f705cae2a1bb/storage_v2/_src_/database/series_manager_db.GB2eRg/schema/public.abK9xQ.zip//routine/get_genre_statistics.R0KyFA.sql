create function get_genre_statistics()
    returns TABLE(genre character varying, total integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT sg.genre, COUNT(*)::INT FROM series_genre sg GROUP BY sg.genre;
END; $$;

alter function get_genre_statistics() owner to postgres;

