create procedure insert_series_actor(IN p_sid integer, IN p_name character varying, IN p_surname character varying, IN p_year_of_birth integer, IN p_nationality character varying)
    language plpgsql
as
$$
DECLARE
    v_actor_id integer;
BEGIN
    -- 1. Pokušaj naći glumca po imenu i prezimenu, ako ga nema - unesi ga
    -- Koristimo ON CONFLICT da izbjegnemo duplikate ako glumac već postoji
    INSERT INTO actor (name, surname, year_of_birth, nationality)
    VALUES (p_name, p_surname, p_year_of_birth, p_nationality)
    ON CONFLICT (name, surname) 
    DO UPDATE SET 
        year_of_birth = EXCLUDED.year_of_birth, 
        nationality = EXCLUDED.nationality
    RETURNING id INTO v_actor_id;

    -- 2. Poveži glumca sa serijom u tablici series_actor
    INSERT INTO series_actor (series_id, actor_id)
    VALUES (p_sid, v_actor_id)
    ON CONFLICT DO NOTHING; -- Ako su već povezani, ne radi ništa
END;
$$;

alter procedure insert_series_actor(integer, varchar, varchar, integer, varchar) owner to postgres;

