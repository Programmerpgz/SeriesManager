create function get_series_by_director(p_did integer)
    returns TABLE(id integer, name character varying, number_of_seasons integer, number_of_episodes integer, year_of_release integer, end_year integer, description text, poster_path character varying, director_id integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM series s WHERE s.director_id = p_did;
END; $$;

alter function get_series_by_director(integer) owner to postgres;

