create function get_platforms_by_series(p_sid integer)
    returns TABLE(platform character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT sp.platform FROM series_platform sp WHERE sp.series_id = p_sid;
END; $$;

alter function get_platforms_by_series(integer) owner to postgres;

