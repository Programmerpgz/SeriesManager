create function get_director_by_id(p_id integer)
    returns TABLE(id integer, name character varying, surname character varying, year_of_birth integer, nationality character varying, biography text)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT d.id, d.name, d.surname, d.year_of_birth, d.nationality, d.biography
    FROM director d 
    WHERE d.id = p_id;
END; 
$$;

alter function get_director_by_id(integer) owner to postgres;

