create procedure create_series_actor(IN p_series_id integer, IN p_actor_id integer)
    language plpgsql
as
$$
BEGIN
    -- Provjeravamo postoji li već ta veza da ne bude duplikata
    IF NOT EXISTS (
        SELECT 1 FROM public.series_actor 
        WHERE series_id = p_series_id AND actor_id = p_actor_id
    ) THEN
        INSERT INTO public.series_actor (series_id, actor_id)
        VALUES (p_series_id, p_actor_id);
    END IF;
END;
$$;

alter procedure create_series_actor(integer, integer) owner to postgres;

