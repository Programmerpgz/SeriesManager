create function search_directors(p_search text)
    returns TABLE(id integer, name character varying, surname character varying, year_of_birth integer, nationality character varying, biography text, image_path character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT d.id, d.name, d.surname, d.year_of_birth, d.nationality, d.biography, d.image_path 
    FROM director d
    WHERE LOWER(d.name) LIKE LOWER('%' || p_search || '%') 
       OR LOWER(d.surname) LIKE LOWER('%' || p_search || '%');
END;
$$;

alter function search_directors(text) owner to postgres;

