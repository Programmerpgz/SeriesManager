create function get_actors_by_nationality(p_nat character varying)
    returns TABLE(id integer, name character varying, surname character varying, year_of_birth integer, nationality character varying, image_path character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT a.id, a.name, a.surname, a.year_of_birth, a.nationality, a.image_path 
    FROM actor a WHERE LOWER(a.nationality) = LOWER(p_nat);
END;
$$;

alter function get_actors_by_nationality(varchar) owner to postgres;

