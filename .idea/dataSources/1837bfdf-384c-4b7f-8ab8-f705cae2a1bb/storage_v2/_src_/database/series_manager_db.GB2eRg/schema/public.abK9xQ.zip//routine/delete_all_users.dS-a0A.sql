create procedure delete_all_users()
    language plpgsql
as
$$
BEGIN
    DELETE FROM users;
END; $$;

alter procedure delete_all_users() owner to postgres;

