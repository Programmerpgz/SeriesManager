create function get_all_directors()
    returns TABLE(id integer, name character varying, surname character varying, year_of_birth integer, nationality character varying, biography text)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT d.id, d.name, d.surname, d.year_of_birth, d.nationality, d.biography 
    FROM director d ORDER BY d.name;
END; 
$$;

alter function get_all_directors() owner to postgres;

