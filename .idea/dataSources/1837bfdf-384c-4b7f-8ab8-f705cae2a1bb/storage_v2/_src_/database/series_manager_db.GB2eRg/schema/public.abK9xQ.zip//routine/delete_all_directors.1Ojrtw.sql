create procedure delete_all_directors()
    language plpgsql
as
$$
BEGIN
    DELETE FROM director;
END;
$$;

alter procedure delete_all_directors() owner to postgres;

