create procedure update_user(IN p_id integer, IN p_username character varying, IN p_password character varying, IN p_name character varying, IN p_surname character varying, IN p_email character varying, IN p_role character varying)
    language plpgsql
as
$$
BEGIN
    UPDATE users 
    SET username = p_username, password = p_password, name = p_name, 
        surname = p_surname, email = p_email, role = p_role
    WHERE id = p_id;
END; $$;

alter procedure update_user(integer, varchar, varchar, varchar, varchar, varchar, varchar) owner to postgres;

