create function get_user_by_username(p_username character varying)
    returns TABLE(id integer, username character varying, password character varying, surname character varying, name character varying, email character varying, role character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM users u WHERE u.username = p_username;
END; $$;

alter function get_user_by_username(varchar) owner to postgres;

