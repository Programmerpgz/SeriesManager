create procedure delete_user(IN p_id integer)
    language plpgsql
as
$$
BEGIN
    DELETE FROM users WHERE id = p_id;
END; $$;

alter procedure delete_user(integer) owner to postgres;

