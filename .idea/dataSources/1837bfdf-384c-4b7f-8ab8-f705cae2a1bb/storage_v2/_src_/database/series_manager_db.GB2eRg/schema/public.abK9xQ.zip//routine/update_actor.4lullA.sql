create procedure update_actor(IN p_id integer, IN p_name character varying, IN p_surname character varying, IN p_year_of_birth integer, IN p_nationality character varying, IN p_image_path character varying)
    language plpgsql
as
$$
BEGIN
    UPDATE actor
    SET name          = p_name,
        surname       = p_surname,
        year_of_birth = p_year_of_birth,
        nationality   = p_nationality,
        image_path    = p_image_path
    WHERE id = p_id;
END;
$$;

alter procedure update_actor(integer, varchar, varchar, integer, varchar, varchar) owner to postgres;

