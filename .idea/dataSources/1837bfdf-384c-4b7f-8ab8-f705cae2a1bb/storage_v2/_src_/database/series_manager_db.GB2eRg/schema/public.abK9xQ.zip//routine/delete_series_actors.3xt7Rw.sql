create procedure delete_series_actors(IN p_sid integer)
    language plpgsql
as
$$ BEGIN DELETE FROM series_actor WHERE series_id = p_sid; END; $$;

alter procedure delete_series_actors(integer) owner to postgres;

