create function get_series_by_platform(p_platform text) returns SETOF series
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT * FROM public.series 
    WHERE platform ILIKE ('%' || p_platform || '%');
END;
$$;

alter function get_series_by_platform(text) owner to postgres;

