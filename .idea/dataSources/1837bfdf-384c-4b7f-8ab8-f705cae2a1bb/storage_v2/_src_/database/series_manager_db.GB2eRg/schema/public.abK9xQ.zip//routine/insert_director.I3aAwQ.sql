create procedure insert_director(IN p_name character varying, IN p_surname character varying, IN p_year_of_birth integer, IN p_nationality character varying, IN p_biography character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO director (name, surname, year_of_birth, nationality, biography)
    VALUES (p_name, p_surname, p_year_of_birth, p_nationality, p_biography);
END;
$$;

alter procedure insert_director(varchar, varchar, integer, varchar, varchar) owner to postgres;

