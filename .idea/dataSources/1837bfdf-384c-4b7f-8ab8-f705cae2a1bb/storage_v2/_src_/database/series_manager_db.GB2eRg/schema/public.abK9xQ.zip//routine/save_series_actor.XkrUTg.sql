create procedure save_series_actor(IN p_series_id integer, IN p_actor_name character varying, IN p_actor_surname character varying)
    language plpgsql
as
$$
DECLARE
    v_actor_id INTEGER;
BEGIN
    SELECT id INTO v_actor_id FROM public.actor 
    WHERE name = p_actor_name AND surname = p_actor_surname LIMIT 1;

    IF v_actor_id IS NULL THEN
        INSERT INTO public.actor (name, surname) VALUES (p_actor_name, p_actor_surname) 
        RETURNING id INTO v_actor_id;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM public.series_actor WHERE series_id = p_series_id AND actor_id = v_actor_id) THEN
        INSERT INTO public.series_actor (series_id, actor_id) VALUES (p_series_id, v_actor_id);
    END IF;
END;
$$;

alter procedure save_series_actor(integer, varchar, varchar) owner to postgres;

