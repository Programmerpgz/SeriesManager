create procedure insert_watchlist_item(IN p_user_id integer, IN p_series_id integer)
    language plpgsql
as
$$
BEGIN
    INSERT INTO watchlist (user_id, series_id)
    VALUES (p_user_id, p_series_id)
    ON CONFLICT (user_id, series_id) DO NOTHING;
END;
$$;

alter procedure insert_watchlist_item(integer, integer) owner to postgres;

