create function get_all_series() returns SETOF series
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT * FROM public.series ORDER BY name;
END;
$$;

alter function get_all_series() owner to postgres;

