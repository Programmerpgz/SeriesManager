create procedure update_director(IN p_id integer, IN p_name character varying, IN p_surname character varying, IN p_birth integer, IN p_nat character varying, IN p_bio text, IN p_path character varying)
    language plpgsql
as
$$
BEGIN
    UPDATE director 
    SET name = p_name, 
        surname = p_surname, 
        year_of_birth = p_birth, 
        nationality = p_nat, 
        biography = p_bio, 
        image_path = p_path
    WHERE id = p_id;
END;
$$;

alter procedure update_director(integer, varchar, varchar, integer, varchar, text, varchar) owner to postgres;

